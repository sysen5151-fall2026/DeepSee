# DeepSee demo: presenter script (about 3 minutes)

**Before class (Windows):** open the unzipped `deepsee-demo` folder and double click
`index.html` (or in PowerShell: `cd ~\Downloads\deepsee-demo` then `start .\index.html`).
Set the browser window to about 1280×720 and click **Overview**. Keep `fallback-screenshots/`
open in File Explorer just in case.

| Time | Click | Say |
| --- | --- | --- |
| 0:00 | Stay on **Overview**. Point to the amber "Demo mode · simulated rules" label. | "This is DeepSee running offline on my laptop with synthetic data. What you'll see are simulated demo results from fixed rules, not a live AI model. The idea: help a clinician notice diagnoses that deserve a second look, while the clinician stays in control." |
| 0:25 | **Open clinician workspace**. Select **Case A**. | "Three invented cases. Case A: 46 years old, nine days after knee surgery, short of breath. The triage note already says likely anxiety." |
| 0:40 | **Continue to clinical data**. Scroll briefly. | "Notes, symptoms, vitals and labs are all editable. Nothing leaves this browser." |
| 0:50 | **Review case**, then **Run simulated analysis**. | "Step 3 is a last check of what goes in. Then the analysis runs locally." |
| 1:00 | Results appear. Point to the amber banner and rank 1. | "Pulmonary embolism comes first, flagged as time sensitive. Here is why: recent surgery, a tight calf, fast heart rate, low oxygen, raised D-dimer. Anxiety is still listed, but low oxygen and the D-dimer count against it. These counts are not probabilities." |
| 1:25 | Point to the evidence trail. | "The trail is honest about what's behind this: our case data and a rule table. The trained model and medical references say Not connected, because they aren't yet." |
| 1:35 | **Mark for review** on rank 1, **Dismiss** on rank 3. | "The clinician decides. DeepSee never finalizes a diagnosis or recommends treatment." |
| 1:50 | Scroll to **Case summary**, type a short clinician note, click **Copy summary**. | "Every action is recorded with a time in a summary the clinician can copy or print." |
| 2:05 | **Start another case** (Case B), **Continue**, **Review case**, **Run simulated analysis**. | "Case B looks like a stomach bug, but glucose 486, low bicarbonate and ketones point to diabetic ketoacidosis, and the stomach bug is listed with the findings that count against it." |
| 2:30 | **Start another case** (Case C), same three clicks. | "An 81 year old whose family thinks she's just tired. The pattern points to sepsis with a possible urinary source, plus low sodium. Older adults often present atypically, which is exactly the kind of case DeepSee is meant for." |
| 2:50 | Click **Recent reviews** in the header. | "All three reviews and their decisions are here. Prototype, not a medical device. Next steps: a validated model and medical references behind every suggestion." |

**If asked "Is this AI?"** "Not yet. This is a transparent rule table we wrote to demonstrate the
workflow and the interface. A trained model is future work, and we don't claim it works today."

**If someone edits a value live:** an amber banner explains that the same fixed rules reran on the
edits. The demo only scans notes for keywords; it does not understand free text.

## Fallback if the live demo stalls

1. **Page looks broken or blank:** press `Ctrl + F5` to reload, or close the tab and double click
   `index.html` again.
2. **Wrong folder:** if `start .\index.html` says it cannot find the file, the zip made a nested
   folder; run `cd .\deepsee-demo` and try again.
3. **Laptop or browser problem:** open `fallback-screenshots/` and walk through, in order,
   `1-home`, `2-workspace-step1`, `3-workspace-step2`, `4-workspace-step3`, `5-results-case-a`,
   `6-actions-full-page`, `5-results-case-b`, `5-results-case-c`, `8-recent-reviews`, using the
   same lines as above.
