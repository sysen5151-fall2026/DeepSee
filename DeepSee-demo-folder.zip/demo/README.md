# DeepSee offline demo

A clickable classroom demo of DeepSee, our proposed on premise clinical decision support tool.
A clinician picks a synthetic case, reviews or edits notes, symptoms, vitals and labs, runs a
**simulated** analysis, and gets a ranked list of conditions to review, each with the findings
behind it. The clinician marks items for review or dismisses them and copies or prints a summary.

The look and layout follow our team repository's frontend (`sysen5151-fall2026/DeepSee`,
folder `frontend/`): same colors, cards, top bar, step by step workspace and our DeepSee logo.
Only the visual design was reused. No application code from the repository runs here, and no
code from the external chest X-ray CDSS reference project was used.

**This is a prototype, not a medical device.** Results come from a small hand written rule table
in `js/rules.js`, not from an AI model. All three cases are invented. Do not enter real patient
information.

## Where this lives

This folder is `demo/` in the DeepSee repository. It is self contained: no `npm install`, no
backend, no build step. From a clone of the repository, run the commands below from inside
`demo/` (for example `cd DeepSee\demo` on Windows or `cd DeepSee/demo` on Mac). If you received
it as `deepsee-demo.zip`, use the unzipped `deepsee-demo` folder instead.

## Run it on Windows (no internet, no install)

**Easiest:** open the folder and double click `index.html`. It opens in your default
browser and works fully from disk (tested). From PowerShell:

```powershell
cd ~\Downloads\deepsee-demo
start .\index.html
```

If unzipping created a nested folder, use `cd ~\Downloads\deepsee-demo\deepsee-demo` first.

**Optional local server** (only if Python is installed; on Windows the command is `py`, not
`python3`):

```powershell
cd ~\Downloads\deepsee-demo
py -m http.server 8000 --bind 127.0.0.1
```

Then open **http://localhost:8000**. Leave PowerShell open while presenting and press `Ctrl + C`
to stop. If port 8000 is busy, use `8001` and open http://localhost:8001.

If PowerShell says "Python was not found", skip the server and use `start .\index.html`.
Everything works the same; only the Copy button may fall back to "Text selected: press Ctrl+C".

## Run it on a Mac

```bash
cd ~/Downloads/deepsee-demo
python3 -m http.server 8000 --bind 127.0.0.1
```

Then open http://localhost:8000, or just double click `index.html`.

For the projector, set the browser window to about 1280×720 and use `Ctrl +` / `Ctrl -`
(`⌘ +` / `⌘ -` on Mac) to adjust zoom.

## The screens

| Screen | What it shows |
| --- | --- |
| Overview | Hero, what DeepSee is for, a static preview card, the three step workflow, demo notice |
| New review (workspace) | Step 1 choose a synthetic case; Step 2 edit notes, symptoms, vitals and labs; Step 3 review the case and run the simulated analysis |
| Results | Priority banner, summary tiles, ranked differential with supporting findings, points against and missing data, evidence trail, case summary with copy and print |
| Recent reviews | Every analysis run in this browser tab, reopenable with its decisions |
| About | What the demo does, what it does not do, and how the rules work |

## What is in the folder

| Path | What it is |
| --- | --- |
| `index.html` | The whole app, with icons inlined |
| `css/styles.css` | Styles in the repository's color scheme. System fonts only, no external assets |
| `assets/deepsee-mark.svg` | Our DeepSee logo, from the team repository |
| `js/data.js` | The three synthetic cases and the form fields |
| `js/rules.js` | The simulated analysis: 8 prepared condition patterns with fixed, illustrative thresholds |
| `js/app.js` | Screens, workspace steps, clinician actions, recent reviews, copy and print |
| `PRESENTER-SCRIPT.md` | One page script: what to click, what to say, fallback plan |
| `fallback-screenshots/` | Screens captured from the tested app, for use if the live demo stalls |
| `docs/PROMPT-LOG-ENTRY.md` | Draft provenance notes for this AI assisted build. Per `docs/prompt-log.md`, the final log entry is written by a reviewer other than Zhuoran Wang |

## How the "analysis" works (say this if asked)

* Each of 8 condition patterns has a list of **supporting findings** and **points against**.
  A finding is a checked symptom, a vital or lab past a fixed threshold, or a keyword in the notes.
* A pattern is shown only if at least 3 supporting findings are present.
* Order = supporting findings minus points against. **These counts are not probabilities or
  confidence scores.**
* An amber **Attention** flag appears on time sensitive patterns (pulmonary embolism, acute coronary
  syndrome, diabetic ketoacidosis, sepsis) when at least 4 supporting findings are present and the
  net count is 3 or more.
* Blank fields are reported as "Not provided, so not evaluated."
* If you edit a case, the same rules run on your edits and a banner says so. The notes are only
  scanned for a few keywords; the demo does not understand free text. For example, the phrase
  "no new weakness" is not interpreted.

## Honest limitations

* No AI model, no medical knowledge base or ontology retrieval, no citations, no EHR or PACS
  connection, no login, and no server side. The evidence trail on the results screen says
  "Not connected" for the model and for medical references.
* Thresholds are illustrative and were not clinically validated. The case content was written for
  teaching, not reviewed by a clinician.
* The 1.2 second loading state is a deliberate pause for the presentation, not processing time.
* Clinician actions, notes and recent reviews are kept only in the open browser tab; refreshing
  clears them.
* This demo uses notes, vitals and labs. It is separate from the chest X-ray prototype in the
  team repository and does not run its code.

## Traceability to our stakeholder requirements

| Requirement (Section 2.6) | How the demo shows it | Status |
| --- | --- | --- |
| SR1 Explanation of results | "Why this appeared", supporting findings and points against on every item | Shown |
| SR5 Clinician control of final decisions | Tool never finalizes anything; clinician marks or dismisses each item | Shown |
| SR6 Integrated clinical review | Case line, findings, evidence trail and summary on one results screen | Shown (synthetic data only) |
| SR11 Patient data containment | Runs entirely in the browser; tested with zero network requests leaving the machine | Shown |
| SR13 Analysis unavailability notification | Not applicable: the rules cannot fail or time out | Not demonstrated |
| SR16 Clinical responsibility notice | Footer on every screen; safeguard box and note under every Attention flag | Shown |
| SR17 Intended use and limitations | About screen, Overview notice and this README | Shown |
| SR18 Audit record of system use | Timestamped clinician actions in the case summary and Recent reviews (in session only) | Partial |
| SR2 to SR4, SR7 to SR10 | Performance, accuracy, adoption and cost targets | Out of scope for a demo |

## Tested

Automated browser test (Chromium via Playwright at 1280×720), run twice: served over
`http://127.0.0.1:8000` and opened directly from disk (`file://`). Both runs passed all 23 checks
with no console errors and no network requests leaving the machine:

* Overview renders with the demo mode label; keyboard Tab and Enter open the workspace
* All three cases: Step 1 to 3, loading state, ranked results, priority banner and tiles
* Mark for review, Dismiss, Restore, with the decision tile and summary updating
* Copy summary (clipboard verified, or the select text fallback), Print summary
* Keyboard Space toggles Mark for review
* Back to case, Reset case to original, Start another case (cycles A, B, C)
* Edited case: banner shown, rules rerun, missing value reported; an edit matching no pattern shows
  the empty state
* Recent reviews lists every run and reopens one with its decisions
* Header navigation, stepper buttons, browser Back, opening `#results` directly
* No visible text smaller than 14 px on any screen
