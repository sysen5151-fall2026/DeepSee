# Prompt log entry: DeepSee offline classroom demo

**Date:** 2026-10-07 · **Run by:** Zhuoran Wang · **Assistant:** Claude (Cowork)
**Reviewed by:** _(teammate, must not be Zhuoran Wang)_

**Built from:** Zhuoran's request for a clickable offline presentation demo (notes, vitals and
labs in; ranked differential with findings out; clinician actions). Constraints given in the prompt:
static HTML/CSS/JS only, no CDNs or remote assets, synthetic data only, label everything as simulated
demo results, do not claim any model, retrieval, citation, validated score or EHR integration, do not
copy the reference CDSS project's code.

**Generated:** `index.html`, `css/styles.css`, `js/data.js` (three synthetic cases),
`js/rules.js` (8 condition patterns with illustrative thresholds), `js/app.js`, README, presenter
script, fallback screenshots.

**Assistant assumptions to review:**

1. The case content, condition patterns and thresholds were written by the assistant for teaching.
   They are not from stakeholders and were not reviewed by a clinician. **Disposition:** open.
   Review before presenting outside class.
2. The demo is a front-end walking skeleton only. It has no backend and no model, so it does not
   exercise the data or model contracts in SPEC.md. **Disposition:** accepted for a presentation demo.
3. The demo maps to SR1, SR5, SR6, SR11, SR16, SR17 and part of SR18; see the README table.
   **Disposition:** open; confirm with the requirements owner.

**Revision:** at Zhuoran's request the interface was restyled to match the team repository's
frontend (colors, cards, top bar, step by step workspace, evidence trail, Recent reviews) and now
uses our DeepSee logo from `frontend/public/deepsee-mark.svg`. Only the visual design and the logo
were reused; the repository's Next.js and Django code was not run or copied into the demo.

**Out of scope, and honoured:** no code from the reference chest X-ray CDSS project was run, copied
or modified. The team repository's application code was not changed.
