/* DeepSee offline demo: screens, 3-step workspace, results, clinician actions.
   Layout follows the DeepSee frontend; everything runs locally in the browser. */
(function () {
  "use strict";
  var D = window.DEEPSEE;
  var $ = function (id) { return document.getElementById(id); };

  var state = {
    caseId: D.CASES[0].id,
    step: 1,
    result: null,   // the review currently shown
    history: []     // reviews run in this tab (newest first)
  };

  function esc(s) {
    return String(s).replace(/[&<>"']/g, function (ch) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[ch];
    });
  }
  function fixture(id) { return D.CASES.filter(function (c) { return c.id === id; })[0]; }
  function letterOf(id) { return String.fromCharCode(65 + D.CASES.indexOf(fixture(id))); }
  function pad(n) { return (n < 10 ? "0" : "") + n; }
  function timeStr(d) { return d.getFullYear() + "-" + pad(d.getMonth() + 1) + "-" + pad(d.getDate()) + " " + pad(d.getHours()) + ":" + pad(d.getMinutes()); }
  function clock(d) { return pad(d.getHours()) + ":" + pad(d.getMinutes()); }

  /* ---------------- Views and routing ---------------- */
  var VIEWS = ["home", "review", "loading", "results", "cases", "about"];
  var HEADINGS = { home: "home-title", review: "review-title", loading: "loading-title", results: "results-title", cases: "cases-title", about: "about-title" };

  function show(view) {
    VIEWS.forEach(function (v) { $("view-" + v).hidden = v !== view; });
    document.querySelectorAll(".nav-link").forEach(function (a) {
      if (a.getAttribute("data-nav") === view) a.setAttribute("aria-current", "page");
      else a.removeAttribute("aria-current");
    });
    window.scrollTo(0, 0);
    var h = $(HEADINGS[view]);
    if (h) { if (!h.hasAttribute("tabindex")) h.setAttribute("tabindex", "-1"); h.focus({ preventScroll: true }); }
  }
  function route() {
    var v = (location.hash || "#home").slice(1);
    if (v === "results" && !state.result) { location.replace("#review"); return; }
    if (VIEWS.indexOf(v) === -1 || v === "loading") v = "home";
    if (v === "results") renderResults();
    if (v === "cases") renderCases();
    show(v);
    if (v === "review") showStep(state.step, false);
  }
  function go(view) {
    if (location.hash === "#" + view) route();
    else location.hash = view;
  }
  function goReview(step) {
    state.step = step;
    go("review");
  }

  /* ---------------- Workspace: build and steps ---------------- */
  function buildForm() {
    $("case-picker").innerHTML = D.CASES.map(function (c, i) {
      return '<button type="button" class="case-card" data-case="' + c.id + '" aria-pressed="false">' +
        '<span class="cc-letter">' + String.fromCharCode(65 + i) + '</span>' +
        '<span class="cc-title">' + esc(c.title) + '</span>' +
        '<span class="cc-meta">' + c.age + ' · ' + esc(c.sex) + ' · synthetic</span>' +
        '<span class="cc-teaser">' + esc(c.teaser) + '</span></button>';
    }).join("");
    $("f-symptoms").innerHTML = D.SYMPTOMS.map(function (s) {
      return '<label class="check"><input type="checkbox" value="' + s.id + '"> ' + esc(s.label) + '</label>';
    }).join("");
    $("f-vitals").innerHTML = D.VITALS.map(function (v) {
      return '<div><label for="v-' + v.id + '">' + esc(v.label) + ' <span class="unit">(' + esc(v.unit) + ')</span></label>' +
        '<input class="input" id="v-' + v.id + '" type="number" step="' + v.step + '" inputmode="decimal"></div>';
    }).join("");
    $("f-labs").innerHTML = D.LABS.map(function (l) {
      if (l.type === "select") {
        return '<div><label for="l-' + l.id + '">' + esc(l.label) + '</label>' +
          '<select class="input" id="l-' + l.id + '"><option value="">Not measured</option><option>Negative</option><option>Positive</option></select></div>';
      }
      return '<div><label for="l-' + l.id + '">' + esc(l.label) + ' <span class="unit">(' + esc(l.unit) + ')</span></label>' +
        '<input class="input" id="l-' + l.id + '" type="number" step="' + l.step + '" inputmode="decimal"></div>';
    }).join("");
  }

  var STEP_TITLES = { 1: "Choose a synthetic case", 2: "Add clinical data", 3: "Review before analysis" };
  function showStep(n, focus) {
    state.step = n;
    [1, 2, 3].forEach(function (i) { $("step-" + i).hidden = i !== n; });
    document.querySelectorAll(".step-btn").forEach(function (b) {
      var s = Number(b.getAttribute("data-step"));
      if (s === n) b.setAttribute("aria-current", "step"); else b.removeAttribute("aria-current");
      b.classList.toggle("done", s < n);
    });
    $("step-label").textContent = "Step " + n + " of 3 · Case " + letterOf(state.caseId);
    $("step-title").textContent = STEP_TITLES[n];
    if (n === 3) renderReviewStep();
    if (focus !== false) {
      var t = $("step-title"); t.setAttribute("tabindex", "-1"); t.focus({ preventScroll: true });
      var main = document.querySelector(".ws-main");
      if (main && main.getBoundingClientRect().top < 70) window.scrollTo(0, 0);
    }
  }

  function loadCase(id) {
    var c = fixture(id);
    state.caseId = id;
    $("f-age").value = c.age;
    $("f-sex").value = c.sex;
    $("f-notes").value = c.notes;
    document.querySelectorAll("#f-symptoms input").forEach(function (cb) { cb.checked = c.symptoms.indexOf(cb.value) !== -1; });
    D.VITALS.forEach(function (v) { $("v-" + v.id).value = c.vitals[v.id] || ""; });
    D.LABS.forEach(function (l) { $("l-" + l.id).value = c.labs[l.id] || ""; });
    document.querySelectorAll(".case-card").forEach(function (b) {
      b.setAttribute("aria-pressed", b.getAttribute("data-case") === id ? "true" : "false");
    });
    $("step-label").textContent = "Step " + state.step + " of 3 · Case " + letterOf(id);
    updateEditState();
  }

  function readForm() {
    var input = { age: $("f-age").value.trim(), sex: $("f-sex").value, notes: $("f-notes").value, symptoms: [], vitals: {}, labs: {} };
    document.querySelectorAll("#f-symptoms input").forEach(function (cb) { if (cb.checked) input.symptoms.push(cb.value); });
    D.VITALS.forEach(function (v) { input.vitals[v.id] = $("v-" + v.id).value.trim(); });
    D.LABS.forEach(function (l) { input.labs[l.id] = $("l-" + l.id).value.trim(); });
    return input;
  }
  function normalize(c) {
    var vit = {}, lab = {};
    D.VITALS.forEach(function (v) { var x = c.vitals[v.id]; vit[v.id] = x === "" || x == null ? "" : String(Number(x)); });
    D.LABS.forEach(function (l) { var x = c.labs[l.id]; lab[l.id] = x === "" || x == null ? "" : (l.type === "select" ? x : String(Number(x))); });
    return JSON.stringify({ age: String(Number(c.age)), sex: c.sex, notes: c.notes.trim(), symptoms: c.symptoms.slice().sort(), vitals: vit, labs: lab });
  }
  function isEdited() { return normalize(readForm()) !== normalize(fixture(state.caseId)); }
  function updateEditState() { $("edit-state").textContent = isEdited() ? "Edited from the original synthetic case" : ""; }

  function metric(label, value) {
    return '<div class="metric' + (value ? "" : " blank") + '"><span>' + esc(label) + '</span><strong>' + esc(value || "Not recorded") + '</strong></div>';
  }
  function renderReviewStep() {
    var i = readForm();
    var bp = i.vitals.sbp && i.vitals.dbp ? i.vitals.sbp + "/" + i.vitals.dbp + " mmHg" : "";
    $("review-metrics").innerHTML =
      metric("Age", i.age ? i.age + " yr" : "") + metric("Sex", i.sex) +
      metric("Temperature", i.vitals.temp ? i.vitals.temp + " °C" : "") +
      metric("Heart rate", i.vitals.hr ? i.vitals.hr + " bpm" : "") + metric("Blood pressure", bp) +
      metric("Resp. rate", i.vitals.rr ? i.vitals.rr + " /min" : "") +
      metric("Oxygen sat.", i.vitals.spo2 ? i.vitals.spo2 + "%" : "");
    var syms = D.SYMPTOMS.filter(function (s) { return i.symptoms.indexOf(s.id) !== -1; });
    $("review-symptoms").innerHTML = syms.length ? syms.map(function (s) { return '<span class="chip">' + esc(s.label) + "</span>"; }).join("") : '<span class="hint">None checked</span>';
    $("review-labs").innerHTML = D.LABS.map(function (l) {
      var v = i.labs[l.id];
      return metric(l.label, v ? v + (l.unit ? " " + l.unit : "") : "");
    }).join("");
    $("review-notes").textContent = i.notes || "No notes entered.";
  }

  /* ---------------- Analyze ---------------- */
  function analyze() {
    var input = readForm();
    var edited = isEdited();
    $("btn-analyze").disabled = true;
    show("loading");
    window.setTimeout(function () {
      var r = {
        input: input, edited: edited, items: D.analyze(input), statuses: {}, actions: [], note: "",
        time: new Date(), caseId: state.caseId, caseTitle: fixture(state.caseId).title, caseLetter: letterOf(state.caseId)
      };
      state.result = r;
      state.history.unshift(r);
      $("btn-analyze").disabled = false;
      go("results");
    }, 1200);
  }

  /* ---------------- Results ---------------- */
  function caseLine(r) {
    var i = r.input;
    var bp = i.vitals.sbp && i.vitals.dbp ? i.vitals.sbp + "/" + i.vitals.dbp : "n/a";
    return "Synthetic patient, " + (i.age || "age not recorded") + ", " + i.sex.toLowerCase() +
      ". HR " + (i.vitals.hr || "n/a") + ", BP " + bp + ", SpO₂ " + (i.vitals.spo2 ? i.vitals.spo2 + "%" : "n/a") +
      ", temp " + (i.vitals.temp ? i.vitals.temp + " °C" : "n/a") + ".";
  }
  function decidedCount(r) {
    return Object.keys(r.statuses).filter(function (k) { return r.statuses[k]; }).length;
  }

  function renderResults() {
    var r = state.result;
    if (!r) return;
    var top = r.items[0];
    var flagged = r.items.filter(function (x) { return x.attention; });
    $("results-kicker").textContent = "Simulated review complete · Case " + r.caseLetter + " · " + clock(r.time);
    $("results-title").textContent = "Case interpretation: " + r.caseTitle;
    $("sc-status").textContent = top ? top.name + " is the leading pattern for review" : "No prepared demo pattern matched";
    $("sc-ic").classList.toggle("calm", !top);
    $("results-caseline").textContent = caseLine(r) + " Use the ranked list as a prompt for clinical review, not as a diagnosis.";
    $("t-patterns").textContent = r.items.length;
    $("t-flags").textContent = flagged.length;
    var dc = decidedCount(r);
    $("t-decision").textContent = dc ? dc + " of " + r.items.length + " decided" : "Pending";
    $("min-support").textContent = D.MIN_SUPPORT;
    $("trail-case").textContent = "Case " + r.caseLetter + ": notes, symptoms, vitals and labs as entered" + (r.edited ? ", including your edits." : ".");
    $("trail-rules").textContent = D.CONDITION_COUNT + " prepared condition patterns with illustrative, unvalidated thresholds. " + r.items.length + " matched this case.";

    var pb = $("priority-banner");
    if (flagged.length) {
      pb.hidden = false;
      pb.innerHTML = '<svg class="ic"><use href="#i-alert"/></svg><div><strong>Priority review suggested</strong><p>' +
        esc(flagged.map(function (f) { return f.name; }).join(", ")) + (flagged.length > 1 ? " match time-sensitive demo patterns" : " matches a time-sensitive demo pattern") +
        " with several supporting findings. Review the full case before deciding next steps.</p></div>";
    } else pb.hidden = true;

    var eb = $("edited-banner");
    if (r.edited) {
      eb.hidden = false;
      eb.innerHTML = '<svg class="ic"><use href="#i-info"/></svg><div><strong>You edited this case</strong><p>These results apply the same fixed demo rules to your edited entries: numeric thresholds, checked symptoms, and a few keywords in the notes. The demo does not understand free text, so a changed result is a rule outcome, not clinical reasoning.</p></div>';
    } else eb.hidden = true;

    $("results-empty").hidden = r.items.length !== 0;
    $("results-list").innerHTML = r.items.map(function (it, idx) {
      var st = r.statuses[it.id] || "";
      var cls = "r-card" + (it.attention ? " is-attention" : "") + (st === "review" ? " is-review" : "") + (st === "dismissed" ? " is-dismissed" : "");
      var pills = "";
      if (it.attention) pills += '<span class="pill pill-attn pill-xs">Attention: time-sensitive pattern</span>';
      if (st === "review") pills += '<span class="pill pill-review pill-xs">Marked for review</span>';
      if (st === "dismissed") pills += '<span class="pill pill-dismissed pill-xs">Dismissed by clinician</span>';
      var actions =
        '<button type="button" class="btn btn-mark" data-act="review" data-id="' + it.id + '" aria-pressed="' + (st === "review") + '"' + (st === "dismissed" ? " disabled" : "") + '>' +
        (st === "review" ? "Marked for review" : "Mark for review") + '</button>' +
        '<button type="button" class="btn" data-act="dismiss" data-id="' + it.id + '">' + (st === "dismissed" ? "Restore" : "Dismiss") + "</button>";
      var head = '<div class="r-head"><span class="r-rank" aria-label="Rank ' + (idx + 1) + '">' + (idx + 1) + "</span>" +
        '<h3 class="r-name">' + esc(it.name) + "</h3>" + pills + '<div class="r-actions">' + actions + "</div></div>" +
        '<p class="r-counts">' + it.supporting.length + " of " + it.supportTotal + " supporting findings · " + it.against.length + " against</p>";
      if (st === "dismissed") return '<li class="' + cls + '">' + head + "</li>";
      var sup = it.supporting.map(function (s) { return "<li>" + esc(s) + "</li>"; }).join("");
      var aga = it.against.length ? it.against.map(function (s) { return "<li>" + esc(s) + "</li>"; }).join("") : '<li class="none">None of the prepared points against were found</li>';
      var why = "<strong>Why this appeared:</strong> " + it.supporting.length + " of the " + it.supportTotal + " supporting findings in this demo pattern are present" +
        (it.against.length ? ", and " + it.against.length + " point" + (it.against.length > 1 ? "s" : "") + " against it" : "") + ". " + esc(it.why);
      var missing = it.missing.length ? '<p class="r-missing"><strong>Not provided, so not evaluated:</strong> ' + esc(it.missing.join(", ")) + "</p>" : "";
      var attn = it.attention ? '<p class="r-attn-note">Flagged because this is a time-sensitive condition pattern with several supporting findings. It is a prompt for clinician review, not a diagnosis.</p>' : "";
      return '<li class="' + cls + '">' + head + '<div class="r-body"><div class="sup"><h3>Supporting findings</h3><ul>' + sup + "</ul></div>" +
        '<div class="aga"><h3>Points against</h3><ul>' + aga + "</ul></div>" + '<p class="r-why">' + why + "</p>" + missing + "</div>" + attn + "</li>";
    }).join("");
    $("f-clin-note").value = r.note || "";
    $("copy-status").textContent = "";
    renderSummary();
  }

  function onResultAction(e) {
    var b = e.target.closest("button[data-act]");
    if (!b || !state.result) return;
    var id = b.getAttribute("data-id"), act = b.getAttribute("data-act");
    var r = state.result, cur = r.statuses[id] || "";
    var name = r.items.filter(function (x) { return x.id === id; })[0].name;
    var next = act === "review" ? (cur === "review" ? "" : "review") : (cur === "dismissed" ? "" : "dismissed");
    r.statuses[id] = next;
    r.actions.push(clock(new Date()) + " " + (next === "review" ? "Marked for review" : next === "dismissed" ? "Dismissed" : "Cleared status") + ": " + name);
    renderResults();
    var again = document.querySelector('button[data-act="' + act + '"][data-id="' + id + '"]');
    if (again) again.focus();
  }

  /* ---------------- Summary, copy, print ---------------- */
  function summaryText() {
    var r = state.result, i = r.input, L = [];
    L.push("DeepSee case summary: SIMULATED DEMO RESULTS (synthetic data, offline rules)");
    L.push("Generated: " + timeStr(r.time));
    L.push("Case: " + r.caseLetter + ". " + r.caseTitle + (r.edited ? " (edited from the original synthetic case)" : ""));
    L.push("Patient: " + (i.age || "age not recorded") + ", " + i.sex);
    var syms = D.SYMPTOMS.filter(function (s) { return i.symptoms.indexOf(s.id) !== -1; }).map(function (s) { return s.label; });
    L.push("Symptoms: " + (syms.length ? syms.join("; ") : "none checked"));
    L.push("Vitals: " + D.VITALS.map(function (v) { return v.label + " " + (i.vitals[v.id] ? i.vitals[v.id] + " " + v.unit : "not recorded"); }).join("; "));
    L.push("Labs: " + D.LABS.map(function (l) { return l.label + " " + (i.labs[l.id] ? i.labs[l.id] + (l.unit ? " " + l.unit : "") : "not measured"); }).join("; "));
    L.push("");
    L.push("Items for clinician review (ordered by demo rule: supporting minus against; not probabilities):");
    if (!r.items.length) L.push("  No prepared demo pattern matched.");
    r.items.forEach(function (it, idx) {
      var st = r.statuses[it.id], tags = [];
      if (it.attention) tags.push("ATTENTION: time-sensitive pattern");
      if (st === "review") tags.push("Marked for review");
      if (st === "dismissed") tags.push("Dismissed by clinician");
      L.push((idx + 1) + ". " + it.name + (tags.length ? " [" + tags.join("; ") + "]" : ""));
      L.push("   Supporting (" + it.supporting.length + " of " + it.supportTotal + "): " + it.supporting.join("; "));
      L.push("   Points against: " + (it.against.length ? it.against.join("; ") : "none found"));
      if (it.missing.length) L.push("   Not provided: " + it.missing.join(", "));
    });
    L.push("");
    L.push("Clinician note: " + (r.note.trim() || "none"));
    L.push("Clinician actions: " + (r.actions.length ? "" : "none"));
    r.actions.forEach(function (a) { L.push("  " + a); });
    L.push("");
    L.push("Prototype, not a medical device. Suggestions are not diagnoses or treatment recommendations; clinician judgment is required.");
    return L.join("\n");
  }
  function renderSummary() { if (state.result) $("summary-text").value = summaryText(); }
  function copySummary() {
    renderSummary();
    var text = $("summary-text").value;
    var done = function (msg) { $("copy-status").textContent = msg; };
    function fallback() {
      var ta = $("summary-text"); ta.focus(); ta.select();
      var ok = false;
      try { ok = document.execCommand("copy"); } catch (e) { ok = false; }
      done(ok ? "Copied" : "Text selected: press Ctrl+C (⌘C on Mac)");
    }
    if (navigator.clipboard && window.isSecureContext) navigator.clipboard.writeText(text).then(function () { done("Copied"); }, fallback);
    else fallback();
  }
  function printSummary() {
    renderSummary();
    $("print-area").textContent = $("summary-text").value;
    window.print();
  }

  /* ---------------- Recent reviews ---------------- */
  function renderCases() {
    var h = state.history;
    $("cases-empty").hidden = h.length !== 0;
    $("cases-list").innerHTML = h.map(function (r, idx) {
      var top = r.items[0], dc = decidedCount(r), tags = "";
      if (r.items.some(function (x) { return x.attention; })) tags += '<span class="pill pill-attn pill-xs">Attention flag</span>';
      if (r.edited) tags += '<span class="tag">Edited case</span>';
      tags += '<span class="tag tag-teal">' + (dc ? dc + " decided" : "Decision pending") + "</span>";
      return '<article class="card case-tile"><p class="mini-kicker">Case ' + r.caseLetter + " · " + timeStr(r.time) + "</p>" +
        "<h2>" + esc(r.caseTitle) + "</h2>" +
        '<p class="ct-lead">' + (top ? "Leading pattern: <strong>" + esc(top.name) + "</strong>" : "No prepared pattern matched") + "</p>" +
        '<p class="ct-meta">' + r.items.length + " pattern" + (r.items.length === 1 ? "" : "s") + " shown · simulated demo results</p>" +
        '<div class="ct-tags">' + tags + "</div>" +
        '<button type="button" class="btn btn-ghost" data-open="' + idx + '">Open review <svg class="ic"><use href="#i-right"/></svg></button></article>';
    }).join("");
  }

  /* ---------------- Wiring ---------------- */
  function startAnother() {
    var idx = D.CASES.indexOf(fixture(state.caseId));
    var next = D.CASES[(idx + 1) % D.CASES.length];
    state.step = 1;
    loadCase(next.id);
    goReview(1);
  }

  function init() {
    buildForm();
    loadCase(state.caseId);

    document.addEventListener("click", function (e) {
      var g = e.target.closest("[data-go]");
      if (g) { var v = g.getAttribute("data-go"); if (v === "review") goReview(1); else go(v); return; }
      var c = e.target.closest(".case-card");
      if (c) { loadCase(c.getAttribute("data-case")); return; }
      var s = e.target.closest(".step-btn");
      if (s) { showStep(Number(s.getAttribute("data-step"))); return; }
      var o = e.target.closest("[data-open]");
      if (o) { state.result = state.history[Number(o.getAttribute("data-open"))]; go("results"); return; }
      var nav = e.target.closest('.nav-link[data-nav="review"]');
      if (nav) { state.step = 1; }
    });
    $("nav-new").addEventListener("click", function () { goReview(1); });
    $("to-step-2").addEventListener("click", function () { showStep(2); });
    $("back-to-1").addEventListener("click", function () { showStep(1); });
    $("to-step-3").addEventListener("click", function () { showStep(3); });
    $("back-to-2").addEventListener("click", function () { showStep(2); });
    $("edit-from-3").addEventListener("click", function () { showStep(2); });
    $("btn-reset").addEventListener("click", function () { loadCase(state.caseId); });
    $("btn-analyze").addEventListener("click", analyze);
    ["input", "change"].forEach(function (ev) { $("step-2").addEventListener(ev, updateEditState); });
    $("btn-back").addEventListener("click", function () { goReview(2); });
    $("btn-back-text").addEventListener("click", function () { goReview(2); });
    $("btn-another").addEventListener("click", startAnother);
    $("results-list").addEventListener("click", onResultAction);
    $("btn-copy").addEventListener("click", copySummary);
    $("btn-print").addEventListener("click", printSummary);
    $("f-clin-note").addEventListener("input", function () { if (state.result) { state.result.note = $("f-clin-note").value; renderSummary(); } });
    window.addEventListener("hashchange", route);
    route();
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init);
  else init();
})();
