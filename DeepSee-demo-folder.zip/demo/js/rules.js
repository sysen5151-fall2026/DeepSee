/*
 * DeepSee offline demo: the simulated "analysis".
 *
 * This is a small, fixed rule table written for the classroom demo.
 * It is NOT a machine learning model, NOT a validated clinical tool,
 * and it does not understand free text. It checks the structured fields
 * against hand-written thresholds and looks for a few keywords in the notes.
 * Thresholds are illustrative only.
 */
window.DEEPSEE = window.DEEPSEE || {};

(function () {
  function num(v) {
    if (v === "" || v === null || v === undefined) return null;
    var n = Number(v);
    return isNaN(n) ? null : n;
  }

  /* Finding helpers. Each returns { label, fields, test(c) }.
   * test returns true / false, or null when a needed field is blank. */
  function sym(id, label) {
    return { label: label, fields: [], test: function (c) { return c.symptoms.indexOf(id) !== -1; } };
  }
  function noSym(id, label) {
    return { label: label, fields: [], test: function (c) { return c.symptoms.indexOf(id) === -1; } };
  }
  function kw(re, label) {
    return { label: label, fields: [], keyword: true, test: function (c) { return re.test(c.notes.toLowerCase()); } };
  }
  function cmp(group, field, op, value, label) {
    return {
      label: label,
      fields: [group + "." + field],
      test: function (c) {
        var x = num(c[group][field]);
        if (x === null) return null;
        if (op === ">") return x > value;
        if (op === ">=") return x >= value;
        if (op === "<") return x < value;
        if (op === "<=") return x <= value;
        return false;
      }
    };
  }
  function range(group, field, lo, hi, label) {
    return {
      label: label,
      fields: [group + "." + field],
      test: function (c) {
        var x = num(c[group][field]);
        if (x === null) return null;
        return x >= lo && x <= hi;
      }
    };
  }
  function either(a, b, label) {
    return {
      label: label,
      fields: a.fields.concat(b.fields),
      test: function (c) {
        var ra = a.test(c), rb = b.test(c);
        if (ra === true || rb === true) return true;
        if (ra === null && rb === null) return null;
        return false;
      }
    };
  }
  function isVal(group, field, value, label) {
    return {
      label: label,
      fields: [group + "." + field],
      test: function (c) {
        var x = c[group][field];
        if (x === "" || x === null || x === undefined) return null;
        return x === value;
      }
    };
  }
  function age(op, value, label) {
    return {
      label: label,
      fields: ["age"],
      test: function (c) {
        var a = num(c.age);
        if (a === null) return null;
        return op === ">=" ? a >= value : a < value;
      }
    };
  }

  var CONDITIONS = [
    {
      id: "pe",
      name: "Pulmonary embolism",
      timeSensitive: true,
      why: "Recent surgery or immobility together with a fast heart rate, fast breathing and low oxygen is a pattern worth review, even when another explanation such as anxiety has already been suggested.",
      support: [
        kw(/surg|post-?op|immobil|long flight|bed ?rest|\bcast\b/, "Recent surgery or immobility mentioned in notes"),
        kw(/calf|leg swell/, "Calf or leg symptoms mentioned in notes"),
        sym("sob", "Shortness of breath"),
        sym("pleuritic", "Sharp chest pain when breathing in"),
        cmp("vitals", "hr", ">", 100, "Heart rate above 100 bpm"),
        cmp("vitals", "rr", ">", 20, "Respiratory rate above 20 /min"),
        cmp("vitals", "spo2", "<", 95, "Oxygen saturation below 95%"),
        cmp("labs", "ddimer", ">", 500, "D-dimer above 500 ng/mL FEU")
      ],
      against: [
        cmp("vitals", "temp", ">=", 38, "Fever of 38.0 °C or higher may point to another cause")
      ]
    },
    {
      id: "acs",
      name: "Acute coronary syndrome",
      timeSensitive: true,
      why: "Chest pressure with sweating, a raised troponin or cardiac risk factors is a pattern worth prompt review.",
      support: [
        sym("pressure", "Chest pressure or tightness"),
        sym("sweating", "Sweating"),
        cmp("labs", "troponin", ">", 14, "Troponin above 14 ng/L (illustrative cut-off)"),
        age(">=", 45, "Age 45 or older"),
        kw(/hypertension|smok|diabet|cholesterol|heart disease/, "Cardiac risk factor mentioned in notes")
      ],
      against: [
        cmp("labs", "troponin", "<=", 14, "Troponin at or below 14 ng/L"),
        sym("pleuritic", "Pain is sharp when breathing in, which is more typical of other causes")
      ]
    },
    {
      id: "dka",
      name: "Diabetic ketoacidosis",
      timeSensitive: true,
      why: "High glucose with low bicarbonate and ketones is a pattern that needs prompt review. Vomiting and abdominal pain can make it look like a stomach illness.",
      support: [
        cmp("labs", "glucose", ">", 250, "Glucose above 250 mg/dL"),
        cmp("labs", "bicarb", "<", 18, "Bicarbonate below 18 mmol/L"),
        isVal("labs", "ketones", "Positive", "Ketones positive"),
        sym("thirst", "Excessive thirst or urination"),
        sym("nausea", "Nausea or vomiting"),
        sym("abdo", "Abdominal pain"),
        cmp("vitals", "rr", ">", 20, "Respiratory rate above 20 /min")
      ],
      against: [
        cmp("labs", "glucose", "<=", 250, "Glucose at or below 250 mg/dL"),
        isVal("labs", "ketones", "Negative", "Ketones negative")
      ]
    },
    {
      id: "sepsis",
      name: "Sepsis, possible urinary source",
      timeSensitive: true,
      why: "Older adults with an infection may show confusion rather than typical symptoms. Abnormal temperature with a fast heart rate, low blood pressure and raised white cells is a pattern that needs prompt review.",
      support: [
        either(cmp("vitals", "temp", ">=", 38, ""), cmp("vitals", "temp", "<", 36, ""), "Temperature 38.0 °C or higher, or below 36.0 °C"),
        cmp("vitals", "hr", ">", 90, "Heart rate above 90 bpm"),
        cmp("vitals", "rr", ">", 20, "Respiratory rate above 20 /min"),
        cmp("labs", "wbc", ">", 12, "White cells above 12 ×10⁹/L"),
        cmp("vitals", "sbp", "<=", 100, "Systolic BP at or below 100 mmHg"),
        sym("confusion", "New confusion"),
        isVal("labs", "nitrite", "Positive", "Urine nitrite positive"),
        sym("dysuria", "Painful urination"),
        kw(/bathroom more|burning|urinary/, "Urinary change mentioned in notes")
      ],
      against: [
        range("vitals", "temp", 36, 37.9, "Temperature in the normal range (36.0 to 37.9 °C)")
      ]
    },
    {
      id: "hypona",
      name: "Low sodium (hyponatremia)",
      timeSensitive: false,
      why: "Low sodium can cause confusion, especially in older adults and in people taking thiazide diuretics.",
      support: [
        cmp("labs", "sodium", "<", 135, "Sodium below 135 mmol/L"),
        sym("confusion", "New confusion"),
        sym("nausea", "Nausea or vomiting"),
        kw(/thiazide|diuretic/, "Thiazide or other diuretic mentioned in notes"),
        kw(/poor appetite|not eating|decreased intake/, "Poor intake mentioned in notes"),
        age(">=", 65, "Age 65 or older")
      ],
      against: [
        cmp("labs", "sodium", ">=", 135, "Sodium 135 mmol/L or higher"),
        cmp("labs", "glucose", ">", 250, "Very high glucose lowers measured sodium, so sodium must be read together with glucose")
      ]
    },
    {
      id: "pneumonia",
      name: "Pneumonia",
      timeSensitive: false,
      why: "Fever, cough, raised white cells, fast breathing and low oxygen together suggest a lung infection pattern.",
      support: [
        cmp("vitals", "temp", ">=", 38, "Temperature 38.0 °C or higher"),
        sym("cough", "Cough"),
        cmp("labs", "wbc", ">", 11, "White cells above 11 ×10⁹/L"),
        cmp("vitals", "spo2", "<", 95, "Oxygen saturation below 95%"),
        cmp("vitals", "rr", ">", 20, "Respiratory rate above 20 /min"),
        sym("sob", "Shortness of breath")
      ],
      against: [
        cmp("vitals", "temp", "<", 37.5, "No fever recorded (below 37.5 °C)"),
        cmp("labs", "wbc", "<=", 11, "White cells at or below 11 ×10⁹/L"),
        noSym("cough", "No cough recorded")
      ]
    },
    {
      id: "anxiety",
      name: "Panic attack or anxiety",
      timeSensitive: false,
      why: "Included because anxiety is mentioned in the notes or the symptoms overlap. Objective findings that anxiety does not explain are listed as points against it.",
      support: [
        kw(/anxi|panic/, "Anxiety or panic mentioned in notes"),
        sym("palpitations", "Palpitations"),
        sym("sob", "Shortness of breath"),
        cmp("vitals", "hr", ">", 100, "Heart rate above 100 bpm")
      ],
      against: [
        cmp("vitals", "spo2", "<", 95, "Oxygen saturation below 95% is not explained by anxiety alone"),
        cmp("labs", "ddimer", ">", 500, "D-dimer above 500 ng/mL FEU"),
        cmp("vitals", "temp", ">=", 38, "Fever of 38.0 °C or higher")
      ]
    },
    {
      id: "gastro",
      name: "Gastroenteritis (stomach bug)",
      timeSensitive: false,
      why: "Vomiting, diarrhea and a sick contact fit a stomach bug. Lab results that a stomach bug does not explain are listed as points against it.",
      support: [
        sym("nausea", "Nausea or vomiting"),
        sym("diarrhea", "Diarrhea"),
        sym("abdo", "Abdominal pain"),
        kw(/stomach bug|food poison|sick contact/, "Sick contact or food exposure mentioned in notes")
      ],
      against: [
        cmp("labs", "glucose", ">", 250, "Glucose above 250 mg/dL is not explained by a stomach bug"),
        cmp("labs", "bicarb", "<", 18, "Bicarbonate below 18 mmol/L"),
        sym("thirst", "Excessive thirst or urination")
      ]
    }
  ];

  var MIN_SUPPORT = 3;

  var FIELD_LABELS = {};
  function fieldLabel(key) {
    if (key === "age") return "Age";
    if (!Object.keys(FIELD_LABELS).length) {
      window.DEEPSEE.VITALS.forEach(function (f) { FIELD_LABELS["vitals." + f.id] = f.label; });
      window.DEEPSEE.LABS.forEach(function (f) { FIELD_LABELS["labs." + f.id] = f.label; });
    }
    return FIELD_LABELS[key] || key;
  }

  /* Returns the ranked list for review. Deterministic: same input, same output. */
  function analyze(c) {
    var results = [];
    CONDITIONS.forEach(function (cond, order) {
      var supporting = [], against = [], missing = {};
      cond.support.forEach(function (f) {
        var r = f.test(c);
        if (r === true) supporting.push(f.label);
        else if (r === null) f.fields.forEach(function (k) { missing[fieldLabel(k)] = true; });
      });
      cond.against.forEach(function (f) {
        var r = f.test(c);
        if (r === true) against.push(f.label);
      });
      if (supporting.length < MIN_SUPPORT) return;
      var score = supporting.length - against.length;
      results.push({
        id: cond.id,
        name: cond.name,
        timeSensitive: cond.timeSensitive,
        why: cond.why,
        supporting: supporting,
        against: against,
        missing: Object.keys(missing),
        supportTotal: cond.support.length,
        score: score,
        attention: cond.timeSensitive && supporting.length >= 4 && score >= 3,
        order: order
      });
    });
    results.sort(function (a, b) {
      if (b.score !== a.score) return b.score - a.score;
      if (b.supporting.length !== a.supporting.length) return b.supporting.length - a.supporting.length;
      return a.order - b.order;
    });
    return results;
  }

  window.DEEPSEE.analyze = analyze;
  window.DEEPSEE.CONDITION_COUNT = CONDITIONS.length;
  window.DEEPSEE.MIN_SUPPORT = MIN_SUPPORT;
})();
