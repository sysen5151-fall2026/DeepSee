/*
 * DeepSee offline demo: synthetic case fixtures and field definitions.
 * Every case here is invented for a classroom demonstration.
 * None of it describes a real person.
 */
window.DEEPSEE = window.DEEPSEE || {};

window.DEEPSEE.SYMPTOMS = [
  { id: "sob", label: "Shortness of breath" },
  { id: "pleuritic", label: "Sharp chest pain when breathing in" },
  { id: "pressure", label: "Chest pressure or tightness" },
  { id: "palpitations", label: "Palpitations" },
  { id: "cough", label: "Cough" },
  { id: "sweating", label: "Sweating" },
  { id: "nausea", label: "Nausea or vomiting" },
  { id: "abdo", label: "Abdominal pain" },
  { id: "diarrhea", label: "Diarrhea" },
  { id: "thirst", label: "Excessive thirst or urination" },
  { id: "dysuria", label: "Painful urination" },
  { id: "confusion", label: "New confusion" },
  { id: "weakness", label: "One-sided weakness" },
  { id: "speech", label: "Speech difficulty" }
];

window.DEEPSEE.VITALS = [
  { id: "temp", label: "Temperature", unit: "°C", step: "0.1" },
  { id: "hr", label: "Heart rate", unit: "bpm", step: "1" },
  { id: "sbp", label: "Systolic BP", unit: "mmHg", step: "1" },
  { id: "dbp", label: "Diastolic BP", unit: "mmHg", step: "1" },
  { id: "rr", label: "Respiratory rate", unit: "/min", step: "1" },
  { id: "spo2", label: "Oxygen saturation", unit: "%", step: "1" }
];

window.DEEPSEE.LABS = [
  { id: "wbc", label: "White blood cells", unit: "×10⁹/L", step: "0.1", type: "number" },
  { id: "sodium", label: "Sodium", unit: "mmol/L", step: "1", type: "number" },
  { id: "glucose", label: "Glucose", unit: "mg/dL", step: "1", type: "number" },
  { id: "bicarb", label: "Bicarbonate", unit: "mmol/L", step: "1", type: "number" },
  { id: "ddimer", label: "D-dimer", unit: "ng/mL FEU", step: "10", type: "number" },
  { id: "troponin", label: "Troponin (hs)", unit: "ng/L", step: "1", type: "number" },
  { id: "ketones", label: "Blood or urine ketones", type: "select" },
  { id: "nitrite", label: "Urine nitrite", type: "select" }
];

/* Empty string = not measured / not provided. */
window.DEEPSEE.CASES = [
  {
    id: "case-a",
    title: "Shortness of breath after surgery",
    teaser: "46-year-old, 9 days after knee surgery. Triage note says “likely anxiety.”",
    age: 46,
    sex: "Female",
    notes:
      "Synthetic case. 46-year-old seen in urgent care 9 days after outpatient knee surgery. " +
      "New shortness of breath since yesterday and sharp chest pain when breathing in. " +
      "Triage note says likely anxiety. No history of lung disease. Left calf feels tight.",
    symptoms: ["sob", "pleuritic", "palpitations"],
    vitals: { temp: "37.3", hr: "112", sbp: "128", dbp: "78", rr: "22", spo2: "93" },
    labs: { wbc: "9.1", sodium: "139", glucose: "104", bicarb: "24", ddimer: "1850", troponin: "9", ketones: "", nitrite: "" }
  },
  {
    id: "case-b",
    title: "Vomiting, abdominal pain and thirst",
    teaser: "23-year-old with vomiting. Roommate recently had a stomach bug.",
    age: 23,
    sex: "Male",
    notes:
      "Synthetic case. 23-year-old with 3 days of vomiting and abdominal pain. Roommate had a stomach bug last week. " +
      "Has been very thirsty and urinating often for about 2 weeks and has lost weight. No known medical history.",
    symptoms: ["nausea", "abdo", "thirst"],
    vitals: { temp: "37.1", hr: "118", sbp: "108", dbp: "66", rr: "28", spo2: "98" },
    labs: { wbc: "13.2", sodium: "132", glucose: "486", bicarb: "11", ddimer: "", troponin: "", ketones: "Positive", nitrite: "" }
  },
  {
    id: "case-c",
    title: "Older adult with new confusion",
    teaser: "81-year-old, 2 days of confusion. Family thinks she is “just tired.”",
    age: 81,
    sex: "Female",
    notes:
      "Synthetic case. 81-year-old brought in by her daughter for 2 days of new confusion and poor appetite. " +
      "Daughter thinks she is just tired. Takes a thiazide diuretic for blood pressure. " +
      "No new weakness or speech problems noted. Has been going to the bathroom more often.",
    symptoms: ["confusion"],
    vitals: { temp: "38.3", hr: "106", sbp: "98", dbp: "58", rr: "22", spo2: "95" },
    labs: { wbc: "15.1", sodium: "127", glucose: "132", bicarb: "21", ddimer: "", troponin: "", ketones: "Negative", nitrite: "Positive" }
  }
];
